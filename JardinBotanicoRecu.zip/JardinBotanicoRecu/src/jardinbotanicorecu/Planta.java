
package jardinbotanicorecu;

import java.util.Objects;


public abstract class Planta {
    
    private String nombre;
    private String ubicacion;
    private String clima;
    
    public Planta(String nombre, String ubicacion, String clima)
    {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    public String getNombre()
    {
        return this.nombre;
    }

    @Override
    public String toString() {
        return "Planta{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", clima=" + clima + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.nombre);
        hash = 79 * hash + Objects.hashCode(this.ubicacion);
        hash = 79 * hash + Objects.hashCode(this.clima);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) 
        {
            return false;
        }
        
        Planta p =(Planta) obj;
        
        return p.nombre.equals(this.nombre) && p.ubicacion.equals(this.ubicacion);
    }
    
    
}
