
package jardinbotanicorecu;


public enum Temporada {
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO;
}
