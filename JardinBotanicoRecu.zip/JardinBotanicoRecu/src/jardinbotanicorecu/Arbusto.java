
package jardinbotanicorecu;


public class Arbusto extends Planta implements Podable{
    
    private static final int MAX_FOLLAJE = 10;
    private static final int MIN_FOLLAJE = 1;
    private int densidadFollaje;
    
    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje)
    {
        super(nombre, ubicacion, clima);
        if(densidadFollaje < MIN_FOLLAJE || densidadFollaje > MAX_FOLLAJE)
        {
            throw new IllegalArgumentException("Esa densidad no esta permitida");
        }
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public void podar()
    {
        System.out.println("El arbusto " + this.getNombre() + " esta siendo podada...");
    }
    
    @Override
    public String toString()
    {
        return "Arbusto{" + "densidadFollaje=" + this.densidadFollaje + super.toString() + '}'; 
    }
}
