
package jardinbotanicorecu;


public class Arbol extends Planta implements Podable{

    private int alturaMaxima;
    
    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima)
    {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }
    
    @Override
    public void podar()
    {
        System.out.println("El arbol " + this.getNombre() + " esta siendo podado...");
    }
    
    @Override
    public String toString()
    {
        return "Arbol{" + "alturaMaxima=" + this.alturaMaxima + super.toString() + '}'; 
    }
}

