
package jardinbotanicorecu;

import java.util.ArrayList;
import java.util.List;



public class JardinBotanico {
    private List<Planta> plantas;
    
    public JardinBotanico()
    {
        this.plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta)
    {
        if(planta == null)
        {
            throw new NullPointerException("Error. Esto no es una planta, es null.");
        }
        if(plantas.contains(planta))
        {
            throw new PlantaDuplicadaException();
        }
        
        plantas.add(planta);
    }
    
    public void mostrarPlanta()
    {
        for(Planta planta : plantas)
        {
            System.out.println(planta);
        }
    }
    
    public void podarPlanta()
    {
        for(Planta planta : plantas)
        {
            if(planta instanceof Podable plantaPodable)
            {
                plantaPodable.podar();
            }
            else
            {
                System.out.println(planta.getNombre() + " no puede ser podada");
            }
        }
        
    }

    @Override
    public String toString() {
        return "JardinBotanico{" + "plantas=" + plantas + '}';
    }
    
    
}
