
package jardinbotanicorecu;


public interface Podable {
    void podar();
}
