
package jardinbotanicorecu;


public class PlantaDuplicadaException extends RuntimeException{
    private static final String MESSAGE = "La planta ya esta en el jardin";
    
    public PlantaDuplicadaException()
    {
        super(MESSAGE);
    }
}
